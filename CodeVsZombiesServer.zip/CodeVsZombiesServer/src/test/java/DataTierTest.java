import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.versionone.DataTier;

class DataTierTest{
    static DataTier dbManager;

    @BeforeAll
    static void init(){
        dbManager = new DataTier();
    }

    // test executeActionQuery() method
    // Add and remove a user
    @Test
    void Test1(){
        // query to add testing user
        String query = "INSERT INTO Users VALUES ('test', 'test', 'test', 1, 1, 1)";

        // execute the query
        dbManager.executeActionQuery(query);

        // read the added data
        query = "SELECT username, password, name, level, iconNumber, progress FROM Users where username = " + "\'test\';";
        ArrayList<ArrayList<String>> data = dbManager.executeReadingQuery(query, 6);

        // test the result
        assertEquals("test", data.get(0).get(0));
        assertEquals("test", data.get(1).get(0));
        assertEquals("test", data.get(2).get(0));
        assertEquals("1", data.get(3).get(0));
        assertEquals("1", data.get(4).get(0));
        assertEquals("1", data.get(5).get(0));

        // remove user after testing
        query = "DELETE FROM Users WHERE username = " + "\'test\';";
        dbManager.executeActionQuery(query);
    }

    // test executeActionQuery() method
    // Modify table's data
    @Test
    void test2(){
         // query to add testing user
         String query = "INSERT INTO Users VALUES ('test', 'test', 'test', 1, 1, 1)";

         // execute the query
         dbManager.executeActionQuery(query);

         // update the data
         query = "UPDATE Users SET username = \'modifiedTest\' ," +
                " password = \'modifiedTest\' , name = \'modifiedTest\'" +
                ", level = 2, progress = 2 , iconNumber = 2 " +
                "WHERE username = \'test\';";
        dbManager.executeActionQuery(query);

         // read the added data
         query = "SELECT username, password, name, level, iconNumber, progress FROM Users where username = " + "\'modifiedTest\';";
         ArrayList<ArrayList<String>> data = dbManager.executeReadingQuery(query, 6);
 
         // test the result
         assertEquals("modifiedTest", data.get(0).get(0));
         assertEquals("modifiedTest", data.get(1).get(0));
         assertEquals("modifiedTest", data.get(2).get(0));
         assertEquals("2", data.get(3).get(0));
         assertEquals("2", data.get(4).get(0));
         assertEquals("2", data.get(5).get(0));
 
         // remove user after testing
         query = "DELETE FROM Users WHERE username = " + "\'modifiedTest\';";
         dbManager.executeActionQuery(query);
    }

    // test executeReadingQuery() method
    // read a user infomation from data base
    @Test
    void Test3(){
        // read the added data
        String query = "SELECT username, password, name, level, iconNumber, progress FROM Users where username = " + "\'test1\';";
        ArrayList<ArrayList<String>> data = dbManager.executeReadingQuery(query, 6);

        // test the result
        assertEquals("test1", data.get(0).get(0));
        assertEquals("test1", data.get(1).get(0));
        assertEquals("test1", data.get(2).get(0));
        assertEquals("1", data.get(3).get(0));
        assertEquals("1", data.get(4).get(0));
        assertEquals("1", data.get(5).get(0));
    }

    // test executeReadingQuery() method
    // read a user infomation from data base
    @Test
    void Test4(){
        // read the added data
        String query = "SELECT username, password, name, level, iconNumber, progress FROM Users where username = " + "\'test2\';";
        ArrayList<ArrayList<String>> data = dbManager.executeReadingQuery(query, 6);

        // test the result
        assertEquals("test2", data.get(0).get(0));
        assertEquals("test2", data.get(1).get(0));
        assertEquals("test2", data.get(2).get(0));
        assertEquals("2", data.get(3).get(0));
        assertEquals("1", data.get(4).get(0));
        assertEquals("1", data.get(5).get(0));
    }

    // test executeReadingQuery() method
    // read a user infomation from data base, no user found
    @Test
    void Test5(){
        // read the added data
        String query = "SELECT username, password, name, level, iconNumber, progress FROM Users where username = " + "\'noneUser\';";
        ArrayList<ArrayList<String>> data = dbManager.executeReadingQuery(query, 6);

        // test the result
        assertEquals(0, data.get(0).size());
        assertEquals(0, data.get(1).size());
        assertEquals(0, data.get(2).size());
        assertEquals(0, data.get(3).size());
        assertEquals(0, data.get(4).size());
        assertEquals(0, data.get(5).size());
    }
};