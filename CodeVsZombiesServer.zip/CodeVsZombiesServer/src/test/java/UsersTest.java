import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.versionone.LoginInfo;
import org.versionone.Users;

public class UsersTest {
    static Users user;
    static LoginInfo info;
    
    @BeforeAll
    static void init(){
        user = new Users();
        info = new LoginInfo();
    }

    //********************************************************************* */
    /*
     * Test CheckCredentials() method
     * Test name: CRTest
     * 
    */
    // login with correct credentials (userType = 2 : users with registered accounts)
    @Test
    void CRTest_1(){
        info.username = "test1";
        info.password = "test1";
        info.userType = 2;

        assertEquals(true, user.checkCredentials(info));
    }

    // login with incorrect credentials (userType = 2 : users with registered accounts)
    @Test
    void CRTest_2(){
        // right username, wrong password
        info.username = "test1";
        info.password = "none";
        info.userType = 2;

        assertEquals(false, user.checkCredentials(info));
    }

    // login with incorrect credentials (userType = 2 : users with registered accounts)
    @Test
    void CRTest_3(){
        // wrong username, correct password
        info.username = "none";
        info.password = "test1";
        info.userType = 2;

        assertEquals(false, user.checkCredentials(info));
    }

    // login with signup option, account not exist (userType = 1 : register for account)
    @Test
    void CRTest_4(){
        info.username = "test11";
        info.password = "test11";
        info.userType = 1;

        assertEquals(true, user.checkCredentials(info));

        // remove account after testing
        user.removeUser(info.username, info.password);
    }

    // login with signup option, account exists (userType = 1 : register for account)
    @Test
    void CRTest_5(){
        info.username = "test11";
        info.password = "test11";
        info.userType = 1;
        // add account to database
        user.checkCredentials(info);

        // test
        assertEquals(false, user.checkCredentials(info));
        
        // remove account after testing
        user.removeUser(info.username, info.password);
    }

    // login with guest option (userType = 3 : guest user)
    @Test
    void CRTest_6(){
        info.userType = 3;

        assertEquals(true, user.checkCredentials(info));
    }

    //********************************************************************* */
    /*
     * Test if the retrieve levels are correct
     * Test name: RLTest
     * 
    */
    @Test
    void RLTest_1(){
        // user level 1
        info.username = "test1";
        info.password = "test1";
        info.userType = 2;
        user.checkCredentials(info);
        assertEquals(1, info.level);

        // user level 2
        info.username = "test2";
        info.password = "test2";
        info.userType = 2;
        user.checkCredentials(info);
        assertEquals(2, info.level);

        // user level 10
        info.username = "test10";
        info.password = "test10";
        info.userType = 2;
        user.checkCredentials(info);
        assertEquals(10, info.level);
    }

    //********************************************************************* */
    /*
     * Test if the progress is retrieve correctly
     * Test name: RPTest
    */
    @Test
    void RPTest_1(){
        // create an account, progress will be 1 by default
        info.username = "test12";
        info.password = "test12";
        info.userType = 1;
        user.checkCredentials(info);
        // read the default progress
        info.userType = 2;
        user.checkCredentials(info);

        // test if progress is 1
        assertEquals(1, info.progress);

        // save new progress = 5 to this user
        user.updateProgress(info.username, 5);

        // read the progress and test if progress is 5
        info.userType = 2;
        user.checkCredentials(info);

        // test if progress is 5
        assertEquals(5, info.progress);

        // remove the test user
        user.removeUser(info.username, info.password);

    }

    //********************************************************************* */
    /*
     * Test updateLevel() method
     * Test name: ULTest
    */
    @Test
    void ULTest_1(){
        // create an account, level will be 1 by default
        info.username = "test12";
        info.password = "test12";
        info.userType = 1;
        user.checkCredentials(info);
        // read the default level
        info.userType = 2;
        user.checkCredentials(info);

        // test if progress is 1
        assertEquals(1, info.level);

        // update new level = 5 to this user
        user.updateLevel(info.username, 5);

        // read the level and test if level is 5
        info.userType = 2;
        user.checkCredentials(info);

        // test if progress is 5
        assertEquals(5, info.level);

        // remove the test user
        user.removeUser(info.username, info.password);

    }

    //********************************************************************* */
    /*
     * Test updateProgress() method
     * Test name: UPTest
    */
    @Test
    void UPTest_1(){
        // create an account, progress will be 1 by default
        info.username = "test12";
        info.password = "test12";
        info.userType = 1;
        user.checkCredentials(info);
        // read the default progress
        info.userType = 2;
        user.checkCredentials(info);

        // test if progress is 1
        assertEquals(1, info.progress);

        // save new progress = 10 to this user
        user.updateProgress(info.username, 10);

        // read the progress and test if progress is 10
        info.userType = 2;
        user.checkCredentials(info);

        // test if progress is 10
        assertEquals(10, info.progress);

        // remove the test user
        user.removeUser(info.username, info.password);

    }
}
