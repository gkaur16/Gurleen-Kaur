
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.versionone.GameQuestions;
import org.versionone.Questions;

class QuestionsTest {
    static Questions questions;
    static GameQuestions q;
    
    @BeforeAll
    static void init(){
        questions = new Questions();
        q = new GameQuestions();
    }

    // test if the question retrieved is correct
    // getQuestions() method, level 1
    @Test
    void test1(){
        // initialize the arrays for actual questions and answers
        ArrayList<String> actualQuestions = new ArrayList<>();
        ArrayList<String> actualAnswers = new ArrayList<>();

        // add the real questions
        actualQuestions.add("There are high level languages and __?__ languages in computers");
        actualQuestions.add("Assembly language is a low level language that is closely related to __?__");
        actualQuestions.add("Python language is very easy to read because it’s uses keywords from __?__ instead of punctuation like other languages.");
        actualQuestions.add("Compiler turns source code to __?__ using the interpreter");
        actualQuestions.add("Python is viewed to be an interpreted language which means you can type the code and interpret it in script mode also get the results directly from __?__ in interactive mode");
        actualQuestions.add("In the interactive mode of interpreter if you input >>> 1 + 1. The output will be __?__");
        actualQuestions.add("In script mode if you input print __?__ the output will be 2");
        actualQuestions.add("A program is a set of __?__ that are used to perform a computation like doing basic mathematical problems or figuring out a letter grade etc.");
        actualQuestions.add("If a program is producing __?__ or not the desired output you can use debugging to track where the error occurs");
        actualQuestions.add("Syntax errors are produced if the instruction given is not legal like 1==0 or (2 or __?__ etc.");

        // add real answers
        actualAnswers.add("low-level");
        actualAnswers.add("computer hardware");
        actualAnswers.add("English language");
        actualAnswers.add("output");
        actualAnswers.add("interpreter");
        actualAnswers.add("2");
        actualAnswers.add("(1+1)");
        actualAnswers.add("instructions");
        actualAnswers.add("errors");
        actualAnswers.add("incorrect indentation");

        // get level 1 questions
        q.level = 1;
        questions.getQuestions(q);  

        // test the results
        for(int i = 0; i < actualQuestions.size(); i++){
            assertEquals(actualQuestions.get(i), q.questions.get(i));
        }

        for(int i = 0; i < actualAnswers.size(); i++){
            assertEquals(actualAnswers.get(i), q.answers.get(i));
        }

    }

    // test if the question retrieved is correct
    // getQuestions() method, level 2
    @Test
    void test2(){
        // initialize the arrays for actual questions and answers
        ArrayList<String> actualQuestions = new ArrayList<>();
        ArrayList<String> actualAnswers = new ArrayList<>();

        // add the real questions
        actualQuestions.add("Programming languages are formal languages that have been designed to express __?__.");
        actualQuestions.add("If we give command print(“Hello World”). The output will be __?__");
        actualQuestions.add("There are different types of values in Python for example 1 is type integer “Hello” is type __?__.");
        actualQuestions.add("If you are not sure of a type in Python you can type it in interpreter like type(__?__) will return <type \'int\'>");
        actualQuestions.add("The result of type(pi) where pi is a mathematical constant which is 3.14 the result will be __?__");
        actualQuestions.add("Float is a number that contains __?__");
        actualQuestions.add("There are variables in python that we use to store a __?__ so we can use that value later.");
        actualQuestions.add("Variables can be of both letters and numbers. It is not legal to start a variable with a __?__");
        actualQuestions.add("There are specific keyword that can’t be used as a variable because they are build to be used for a specific task for example if, elif, else, continue, __?__");
        actualQuestions.add("We can set x = 40 and then if we do print(x) the resulting value will be __?__");

        // add real answers
        actualAnswers.add("computations");
        actualAnswers.add("Hello World");
        actualAnswers.add("string");
        actualAnswers.add("17");
        actualAnswers.add("<type \'float\'>");
        actualAnswers.add("decimal places");
        actualAnswers.add("value");
        actualAnswers.add("number");
        actualAnswers.add("print");
        actualAnswers.add("40");

        // get level 2 questions
        q.level = 2;
        questions.getQuestions(q);

        // test the results
        for(int i = 0; i < actualQuestions.size(); i++){
            assertEquals(actualQuestions.get(i), q.questions.get(i));
        }

        for(int i = 0; i < actualAnswers.size(); i++){
            assertEquals(actualAnswers.get(i), q.answers.get(i));
        }
    }

    // test if the question retrieved is correct
    // getQuestions() method, wrong level = -1
    @Test
    void test3(){
        // get level -1 questions
        q.level = -1;
        questions.getQuestions(q);

        // test the results
        assertEquals(0, q.questions.size());
        assertEquals(0, q.answers.size());
        for(List<String> arr : q.wrongAnswers){
            assertEquals(0, arr.size());
        }

    }
};