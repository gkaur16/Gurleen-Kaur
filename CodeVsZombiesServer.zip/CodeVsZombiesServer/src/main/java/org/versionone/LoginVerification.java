package org.versionone;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginVerification {
	// URL, username and password of local mySQL database
	String dbURL = "jdbc:mysql://127.0.0.1:3306/CodeVsZombiesDB";
	String dbUsername = "java";
	String dbPassword = "password";
	Connection conn;
	
	public LoginVerification() throws IllegalArgumentException, InvocationTargetException, SecurityException {
		// TODO Auto-generated constructor stub
		try {

			conn = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// check if the user's credential exists in the database
	public boolean checkCredentials(LoginInfo info) {
		Statement stmt = null;
		ResultSet rs = null;
		
		// set up the statement
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(info.userType == 3) {
			// userType = 3 => Guest login
			info.level = 1;
			return true;
		}
		else {
			try {
				// execute query the retrieve username and password
				if (stmt.execute("SELECT username, password, level FROM Users;")) {
				    rs = stmt.getResultSet();

				    while (rs.next()) {
						// retrieve the data in each column, aka username/password/level
				    	String temp1 = rs.getString(1);
				    	String temp2 = rs.getString(2);
						int temp3 = Integer.parseInt(rs.getString(3));
				    	if(temp1.contains(info.username)  && info.username.contains(temp1)) {
				    		// the username and password are found in the database
							if(info.userType == 2 && temp2.contains(info.password) && info.password.contains(temp2)){
								// the user chose login option
								// get the user's level saved in the database
								info.level = temp3;

								// set login check boolean to true
								return true;
							}
							else if(info.userType == 1){
								// the user chose register option
								// the account already exists, return false
								
								// set login check boolean to false
								return false;
							}

				    	}
				    }
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(info.userType == 1){
				// userType == 1 => register
				// insert username and password to the database if the user has not registered
				// setup the query
				String str = "INSERT INTO Users VALUES(\'" + info.username + "\',\'" + info.password + "\', 1);";
				
				try {
					stmt.execute(str);
					System.out.println("User registered to the server, username: " 
												+ info.username + ", password: " + info.password);
					
					// set check login boolean and level
					info.level = 1;
					return true;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("User has failed to register to the server!");
					//e.printStackTrace();
				}
			}
			
		}
		
		return false;
	}

	// close MySQL connection
	void closeMySQLConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
