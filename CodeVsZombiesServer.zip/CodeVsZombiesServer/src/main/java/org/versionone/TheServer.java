package org.versionone;

import org.versionone.ClientThread;

import java.io.IOException;
import java.net.ServerSocket;

public class TheServer extends Thread{
	private int port;
	int count = 1;
	
	public TheServer(int port) {
		// TODO Auto-generated constructor stub
		this.port = port;
		
		// start the thread
		this.start();
	}

	//run Thread
	public void run() {
		try(ServerSocket mySocket = new ServerSocket(this.port);) {
			System.out.println("The server is waiting for client!");
			// server waiting for connection from clients
			while(true) {
				ClientThread client = new ClientThread(mySocket.accept(), count);
				System.out.println("Client #" + count + " has connected to the server!");
				count++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("The client couldn't connect to the server");
			e.printStackTrace();
		}
		
		
	}
}
