package org.versionone;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Questions {
    // URL, username and password of local mySQL database
	String dbURL = "jdbc:mysql://127.0.0.1:3306/CodeVsZombiesDB";
	String dbUsername = "java";
	String dbPassword = "password";
	Connection conn;
	DataTier dataTier;

	public Questions() {
		// initialize database manager
		dataTier = new DataTier();
	}

    public void getQuestions(GameQuestions q){
		// setup the query
		String query = "SELECT question, correctAnswer, wrongAnswers "
						+ "FROM questions, answers "
						+ "WHERE questions.id = answers.id and level = " + Integer.toString(q.level) + ";";

		// execute query to read data from the database
		ArrayList<ArrayList<String>> data = this.dataTier.executeReadingQuery(query, 3);

		// clear all the arrays of strings in GameQuestions object before
		// adding the values in them
		q.questions.clear();
		q.answers.clear();
		q.wrongAnswers.clear();

		// parse the wrong answers
		for(String s : data.get(2)){
			// save the wrong answers to an array
			String[] temp = s.split("[?]+");

			//put the wrong answers into a list
			List<String> tmpWrongAnswers = new ArrayList<>();
			for(String str : temp){
				tmpWrongAnswers.add(str);
			}

			// save the wrong answers to object
			q.wrongAnswers.add(tmpWrongAnswers);
		}

		// save the questions and answers to the GameQuestions object
		q.questions.addAll(data.get(0));
		q.answers.addAll(data.get(1));
    }

	// print all the questions that read based on the level of the user
	private void printQuestions(GameQuestions q){
		System.out.println("***Questions and answers for level " + q.level);
		for(int i = 0; i < q.questions.size(); i++){
			System.out.println("Question #" + i + ":");
			System.out.println(q.questions.get(i));
			System.out.println("\tCorrect Answer: " + q.answers.get(i));
			System.out.print("\tWrong Answers: " );
			for(String s : q.wrongAnswers.get(i)){
				System.out.print(s + ", ");
			}
			System.out.println(" ");
		}
	}

	// close MySQL connection
	void closeMySQLConnection(){
		dataTier.closeMySQLConnection();
	}
}
