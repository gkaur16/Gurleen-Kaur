package org.versionone;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Users {
	// URL, username and password of local mySQL database
	String dbURL = "jdbc:mysql://127.0.0.1:3306/codevszombiesdb";
	String dbUsername = "java";
	String dbPassword = "password";
	Connection conn;
    Statement stmt;
	ResultSet rs;
	DataTier dataTier;
	
	public Users() {
		// initialize database manager
		dataTier = new DataTier();
	}

	// check if the user's credential exists in the database
	public boolean checkCredentials(LoginInfo info) {
		
		if(info.userType == 3) {
			// userType = 3 => Guest login
			info.level = 1;
			return true;
		}
		else {
			// setup query
			String query = "SELECT username, password, level, iconNumber, progress, name " +
							"FROM Users WHERE username = '" + info.username + "' AND password = '" + info.password + "';";
			
			// execute query to get the data
			ArrayList<ArrayList<String>> data = this.dataTier.executeReadingQuery(query, 6);

			if(data.get(0).size() == 0){
				// if the user chose register option
				if(info.userType == 1){
					// register the account to database
					// set level to 1
					info.level = 1;

					// setup the query
					query = "INSERT INTO Users VALUES(\'" + info.name + "\',\'" + info.username + "\',\'" 
					+ info.password + "\', 1," + info.iconNumber + ", " + info.level + ");";

					// execute the query to register the account
					if(this.dataTier.executeActionQuery(query)){
						return true;
					}
					else{
						// register failed
						return false;
					}
				}
				else if(info.userType == 2){
					// no data found, the user has entered the wrong credentials
					return false;
				}
			}
			else{
				// the user chose login option
				if(info.userType == 2){
					// get the user's level, iconNumber, progress saved in the database
					info.level = Integer.parseInt(data.get(2).get(0));
					info.iconNumber = Integer.parseInt(data.get(3).get(0));
					info.progress = Integer.parseInt(data.get(4).get(0));
					info.name = data.get(5).get(0);

					// set login check boolean to true
					return true;
				}
				else if(info.userType == 1){
					// the user chose register option
					// the account already exists, return false
					return false;
				}
			}
		}
		
		return false;
	}

    // update level of the user
    public void updateLevel(String username, int level){
        String query = "UPDATE Users SET level = " + Integer.toString(level) + " "
                       + "WHERE username = " + "\'" + username + "\';";
        
        // execute the query
		dataTier.executeActionQuery(query);
    }

	// update the progress of the user
	public void updateProgress(String username, int progress){
		String query = "UPDATE Users SET progress = " + Integer.toString(progress) + " "
                       + "WHERE username = " + "\'" + username + "\';";
        
        // execute the query
		dataTier.executeActionQuery(query);
	}

	// close MySQL connection
	public void closeMySQLConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 
	public void removeUser(String username, String password){
		String query = "DELETE FROM Users " + " "
                       + "WHERE username = " + "\'" + username + "\' AND password = " + "\'" + username + "\';";
        
		// execute the query
        dataTier.executeActionQuery(query);
	}
}
