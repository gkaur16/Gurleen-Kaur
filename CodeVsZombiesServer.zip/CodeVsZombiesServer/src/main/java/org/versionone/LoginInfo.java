package org.versionone;

import java.io.Serializable;

public class LoginInfo implements Serializable{
/**
     *
     */
    private static final long serialVersionUID = 1L;
    //private static final long serialVersionUID = 1L;
    public String username;
    public String password;
    public String name; // name of the user when they register
    public int userType;//  1: register, 2:login , 3: Guest user
    public int level; // level of the user
    public int iconNumber; // number of the icon to show in the account
    public int progress; // the number of the question that the user left off when they play the level current to their level

    // @param: check
	// register(userType = 1): if failed, the user has registered with the same username on the database
	// login(userType = 2): if failed, the user has entered the wrong login credentials
	// guest(userType = 3): always set to true
	public boolean check; // check if user entered correct info

    public LoginInfo() {
        name = "";
        username = "";
        password = "";
        userType = 1;
        level = 1;
		iconNumber = 1;
        check = false;
        progress = 1;
    }
}
