package org.versionone;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.Socket;

public class ClientThread extends Thread {

	Socket clientSocket;
	ObjectInputStream in;
	ObjectOutputStream out;
	int clientNumber, currentLevel;
	String username;
	int userType;

	public ClientThread(Socket s, int count) {
		// TODO Auto-generated constructor stub
		this.clientSocket = s;
		this.clientNumber = count;
		this.currentLevel = 1;
		username = "";

		// start the Thread
		this.start();
	}

	// run the Thread
	public void run() {
		// create the streams
		this.createStreams();

		while(true){
			boolean islogin = false;

			// get the object from the client
			Object gamePackage = null;

			try {
				gamePackage = in.readObject();
			} catch (ClassNotFoundException | IOException e1) {
				// TODO Auto-generated catch block
				System.out.println("The client has left the server: " + e1.getMessage());
				break;
			}

			// attempt to convert the gamePackage object to LoginInfo 
			try{
				LoginInfo info = (LoginInfo) gamePackage;
				
				// set the boolean to indicate that the received object is LoginInfo
				islogin = true;
				this.handleLoginInfo(info);
			}catch(ClassCastException e){
				System.out.println("");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				System.out.println("The client has left the server: " + e1.getMessage());
				break;
			}

			// the gamePackage object is not LoginInfo, attempt to convert
			// it to GameQuestions
			if(islogin == false){
				try{
					GameQuestions questions = (GameQuestions) gamePackage;

					// handle questions requests
					this.handleGameQuestions(questions);
				}catch(ClassCastException e){
					System.out.println("");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					System.out.println("The client has left the server: " + e1.getMessage());
					break;
				}
			}
			
			// KEEP THIS BLOCK BELOW FOR LATER PREFERENCES, WILL DELETE IT
			// WHEN THE UPDATES ARE VERIFIED TO WORK WELL  

			// // waiting for the client to send data
			// if (true) {
			// 	try {
			// 		// save the login info aka username/password to info object
			// 		//LoginInfo info = (LoginInfo) in.readObject();
			// 		//LoginInfo info = (LoginInfo) thispackage;
			// 		// messages for testing on server
			// 		System.out.println("client username: " + info.username);
			// 		System.out.println("client password: " + info.password);
			// 		System.out.println("client type: " + info.userType);

			// 		// check the login credentials
			// 		// create login checking object
			// 		// check if client sent username
			// 		info.check = user.checkCredentials(info);
			// 		System.out.println("Start sending login info object back....");
			// 		// send LoginInfo object back to the client
			// 		out.writeObject(info);
			// 		// reset the output stream
			// 		out.reset();
			// 		System.out.println("Object sent!");
			// 		// check if the client has logged in successfully
			// 		if (info.check == true) {
			// 			// user has logged in successfully
			// 			System.out.println("Login succeeded!");
			// 			// get the name of the user
			// 			this.username = info.username;
			// 			// get the type of the user
			// 			this.userType = info.userType;
			// 			break;
			// 		} else {
			// 			System.out.println("Login failed!");
			// 		}

			// 	} catch (ClassNotFoundException | IOException | IllegalArgumentException | SecurityException e) {
			// 		// TODO Auto-generated catch block
			// 		System.out.println("Client has left the server: " + e.getMessage());
			// 		break;
			// 	}
			// }
			
			// Questions temp = new Questions();
			// if (true) {
			// 	try {
			// 		// waiting for client to send request for questions/answers
			// 		//GameQuestions questions = (GameQuestions) in.readObject();

			// 		// Here, need to update the level of the user in the database
			// 		// if the user is register/login type player, and the level of the
			// 		// questions to retrieve greater than current level of user.
			// 		// Dont update if the user is guest
			// 		if(questions.level > this.currentLevel 
			// 			&& this.userType != 3
			// 			&& questions.updateLevel == true){
			// 			// update user's current level
			// 			this.currentLevel = questions.level;

			// 			// update level of user in the database
			// 			user.updateLevel(this.username, questions.level);
			// 		}
					
			// 		// if the client request updating the level, do not
			// 		// retrieve the questions/answers
			// 		// otherwise, read the questions and send to client
			// 		if(questions.updateLevel == false && questions.updateProgress == false){
			// 			// read questions from database
			// 			temp.getQuestions(questions);

			// 			// send the questions/answers to the client
			// 			System.out.println("Sent questions of level " + questions.level + " to the client!");
			// 			out.writeObject(questions);
			// 			out.reset();
			// 		}
			// 		else if(questions.updateProgress == true){
			// 			// update the progress in the database
			// 			user.updateProgress(this.username, questions.progress);
			// 		}
			// 	} catch (ClassNotFoundException | IOException e) {
			// 		// TODO Auto-generated catch block
			// 		System.out.println("Client has left the server: " + e.getMessage());
			// 		// close MySQL connection
			// 		user.closeMySQLConnection();
			// 		break;
			// 	}
			// }
		}
	}

	private void handleLoginInfo(LoginInfo info) throws IOException{
		// create Users class object for manipulating user's table in database
		Users user = new Users();

		// messages for testing on server
		System.out.println("client username: " + info.username);
		System.out.println("client password: " + info.password);
		System.out.println("client type: " + info.userType);

		// check the login credentials
		// create login checking object
		// check if client sent username
		info.check = user.checkCredentials(info);
		
		// check if the client has logged in successfully
		if (info.check == true) {
			// user has logged in successfully
			System.out.println("Login succeeded!");
			// get the name of the user
			this.username = info.username;
			// get the type of the user
			this.userType = info.userType;
		}
		else {
			System.out.println("Login failed!");
		}

		System.out.println("Start sending login info object back....");
		// send LoginInfo object back to the client
		out.writeObject(info);
		// reset the output stream
		out.reset();
		System.out.println("Object sent!");
		
	}

	private void handleGameQuestions(GameQuestions questions) throws IOException{
		// create Users class object for manipulating Users table in database
		Users user = new Users();

		// create Questions class object for manipulating questions/answers table in database
		Questions temp = new Questions();

		// Here, need to update the level of the user in the database
		// if the user is register/login type player, and the level of the
		// questions to retrieve greater than current level of user.
		// Dont update if the user is guest
		if(questions.level > this.currentLevel 
			&& this.userType != 3
			&& questions.updateLevel == true){
			// update user's current level
			this.currentLevel = questions.level;

			// update level of user in the database
			user.updateLevel(this.username, questions.level);
		}
		
		// if the client request updating the level, do not
		// retrieve the questions/answers
		// otherwise, read the questions and send to client
		if(questions.updateLevel == false && questions.updateProgress == false){
			// read questions from database
			temp.getQuestions(questions);

			// send the questions/answers to the client
			System.out.println("Sent questions of level " + questions.level + " to the client!");
			out.writeObject(questions);
			out.reset();
		}
		else if(questions.updateProgress == true){
			// update the progress in the database
			user.updateProgress(this.username, questions.progress);
		}
	}

	// create the streams for communication with the client
	private void createStreams(){
		try {
			// create input and output streams
			this.in = new ObjectInputStream(clientSocket.getInputStream());
			this.out = new ObjectOutputStream(clientSocket.getOutputStream());

			// set no delay for package sending
			clientSocket.setTcpNoDelay(true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Create a Questions class object to read the questions and
	// answers from the database
	void getQuestions(GameQuestions q){
		Questions temp = new Questions();
		temp.getQuestions(q);
		temp.closeMySQLConnection();
	}
}
