package org.versionone;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DataTier {
    // URL, username and password of local mySQL database
	String dbURL = "jdbc:mysql://127.0.0.1:3306/codevszombiesdb";
	String dbUsername = "java";
	String dbPassword = "password";
	Connection conn;
    Statement stmt;
	ResultSet rs;

    public DataTier() {
		try {
            // Connect to the database
			conn = DriverManager.getConnection(dbURL, dbUsername, dbPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // set up the statement
		try {
			stmt = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// execute the query
	public boolean executeActionQuery(String query){
		try {
            this.stmt.execute(query);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("Failed to execute query: " + e.getMessage()) ;
			return false;
        }
		
		return true;
	}

	// execute the query to read data from the database
	// the data read from the database is stored in a 2D array
	// numCol is the number of column read from the database
	public ArrayList<ArrayList<String>> executeReadingQuery(String query, int numCol){
		// initialize the 2D array to hold the data
		ArrayList<ArrayList<String>> data = new ArrayList<>(numCol);
		for(int i = 0; i < numCol; i++){
			data.add(new ArrayList<String>());
		}

		// execute query the retrieve username and password
		try {
			if (stmt.execute(query)) {
				rs = stmt.getResultSet();

				while (rs.next()) {
					// get the retrieved data
					for(int i = 0; i < numCol; i++){
						data.get(i).add(rs.getString(i + 1));
					}
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return data;
	}

	// close MySQL connection
	public void closeMySQLConnection(){
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void finalize(){
		if(this.conn != null)
			this.closeMySQLConnection();
	}
};