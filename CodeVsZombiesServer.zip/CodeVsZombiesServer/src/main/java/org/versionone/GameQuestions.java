package org.versionone;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/* This is the object sent between the server and the database for questions/answers
*  -> the client just sets the level of questions and sends to server.
*  -> the server sends the questions, answers, and wrong answers stored in Lists for client to display
* */
public class GameQuestions implements Serializable {
    private static final long serialVersionUID = 1L;
    public List<String> questions;
    public List<String> answers;
    public List<List<String>> wrongAnswers;
    public int level;
    boolean updateLevel; // retrieve the questions if false, update user's level otherwise
    int progress;
    boolean updateProgress; // update the progress of the user in the database if true.

    // init the arrays to 10, each level has 10 questions
    public GameQuestions(){
        this.questions = new ArrayList<String>(10);
        this.answers = new ArrayList<String>(10);
        this.wrongAnswers = new ArrayList<List<String>>(10);
        for (int i=0;i<10;i++)
            this.wrongAnswers.add(new ArrayList<String>());
        this.level = -1;
        progress = 1;
        updateLevel = false;
        updateProgress = false;
    }

    public List<String> getQuestions(){return this.questions;}
    public List<String> getAnswers(){return this.answers;}
    public List<List<String>> getWrongAnswers(){return this.wrongAnswers;}

    // print all the questions that read based on the level of the user
	public void printQuestions(){
		System.out.println("***Questions and answers for level " + this.level);
		for(int i = 0; i < this.questions.size(); i++){
			System.out.println("Question #" + i + ":");
			System.out.println(this.questions.get(i));
			System.out.println("\tCorrect Answer: " + this.answers.get(i));
			System.out.print("\tWrong Answers: " );
			for(String s : this.wrongAnswers.get(i)){
				System.out.print(s + ", ");
			}
			System.out.println(" ");
		}
	}
}
