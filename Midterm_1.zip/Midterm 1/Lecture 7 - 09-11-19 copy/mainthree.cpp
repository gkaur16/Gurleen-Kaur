/*main.cpp*/

//
// Netflix movie analysis: top-10 by rating and # of reviews.
//
// Prof. Joe Hummel
// Windows with Visual Studio
// U. of Illinois, Chicago
// CS341, Spring 2017
// Project #01: Solution
//

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;


//
// Movie class:
//
class Movie
{
private:
  int     ID;
  string  Name;
  int     PubYear;
  int     NumReviews;
  double  SumRatings;
  double  AvgRating;

public:
  //
  // constructor:
  //
  Movie(int id, string name, int pubyear)
    : ID(id), Name(name), PubYear(pubyear)
  {
    NumReviews = 0;
    SumRatings = 0.0;
    AvgRating = 0.0;
  }

  //
  // getters/setters:
  //
  int getMovieID() const
  {
    return ID;
  }

  string getMovieName() const
  {
    return Name;
  }

  int getPubYear() const
  {
    return PubYear;
  }

  int getNumReviews() const
  {
    return NumReviews;
  }

  void increaseNumReviews()
  {
    NumReviews++;
  }

  void increaseSumRatings(int rating)
  {
    SumRatings += rating;
  }

  //
  // returns average rating for this movie:
  //
  double getAvgRating() const
  {
    if (NumReviews == 0)
      return 0.0;
    else
      return SumRatings / NumReviews;
  }
};

/*
Movie & FindMovie(vector<Movie>& movies, int movieID)
{
	for (Movie &m : movies)
	{
		if (m.getMovieID() == movieID)
			return m;
	}
	return NULL;
}*/

/*int FindMovie(vector<Movie>& movies, int movieID)
{
	for (int i = 0; i < movies.size(); ++i)
	{
		if (movies[i].getMovieID() == movieID)
			return i;
	}
	return -1;
}*/

//
// FindMovie: searches the vector for the movie with matching
// movie id; returns index >= 0 if found, -1 if not.
//
int FindMovie1(vector<Movie>& movies, int movieID)
{
  for (size_t i = 0; i < movies.size(); ++i)
  {
    if (movies[i].getMovieID() == movieID)
      return (int) i;
  }

  // if get here, not found:
  return -1;
}

// Pointers vs References
//
// Pointers can be null, references can not
// Pointer arithmetic - offers essentially unlimited access to memory
// Pointers can be invalid, references must be valid
// Pointers can change what they point to, references can not
// Pointers and references allow us to modify the things they point to.

Movie *FindMovie2(vector<Movie>& movies, int movieID)
{
  for (Movie& m : movies)
  {
    if (m.getMovieID() == movieID)
      return &m;
  }

  return nullptr;
}

auto FindMovie(vector<Movie>& movies, int movieID)
{
  auto result = std::find_if(movies.begin(),
    movies.end(),
    [=](const Movie& m)
    {
	  if (m.getMovieID() == movieID)
        return true;
      else
        return false;
    }
  );

  return result;
}

//
// InputMovies: inputs the movies from the given file, and stores
// the data in a vector of Movie objects.  The vector is returned.
//
vector<Movie> InputMovies(string filename)
{
  ifstream file(filename);
  vector<Movie> movies;
  string line;

  if (!file.good())
  {
    cout << "**Error: cannot open file: " << filename << endl;
    std::terminate();
  }

  getline(file, line);  // discard first line (column headers):

  while (getline(file, line))
  {
    stringstream  ss(line);

    // format: MovieID,MovieName,PubYear
    string movieID, name, year;

    getline(ss, movieID, ',');
    getline(ss, name, ',');
    getline(ss, year);

    Movie m(stoi(movieID), name, stoi(year));

    movies.push_back(m);
  }

  //
  // done, return input:
  //
  return movies;
}


//
// ProcessReviews: inputs reviews from the given file, and for each
// review updates the corresponding movie: # of reviews and sum of
// ratings.  Returns the # of reveiws processed.
//
int ProcessReviews(string filename, vector<Movie>& movies)
{
  ifstream file(filename);
  int N = 0;
  string line;

  if (!file.good())
  {
    cout << "**Error: cannot open file: " << filename << endl;
    std::terminate();
  }

  getline(file, line);  // discard first line (column headers):

  while (getline(file, line))
  {
    N++;

    stringstream  ss(line);

    // format: MovieID,UserID,Rating,ReviewDate
    string movieID, userID, rating;

    getline(ss, movieID, ',');
    getline(ss, userID, ',');
    getline(ss, rating);
    // ignore review date, we don't need it:

    //
    // now that we've parsed the review, search for corresponding
    // movie and update:
    //
    int i = FindMovie1(movies, stoi(movieID));
    if (i >= 0)
    {
      movies[i].increaseNumReviews();
      movies[i].increaseSumRatings(stoi(rating));
    }

    //Movie *mp = FindMovie2(movies, stoi(movieID));
    //if (mp != nullptr)
    //{
    //  mp->increaseNumReviews();
    //  mp->increaseSumRatings(stoi(rating));
    //}

    //auto m_iter = FindMovie3(movies, stoi(movieID));
    //if (m_iter != movies.end())
    //{
    //  m_iter->increaseNumReviews();
    //  m_iter->increaseSumRatings(stoi(rating));
    //}
  }

  //
  // done, return # of reviews processed:
  //
  return N;
}


//
// SortMoviesByAvgRatingDesc: sorts the movies by their average rating, in
// descending order; secondary sort by Movie name when the avgs are equal.
//
// NOTE: since N is small, simple selection sort is used.
//
void SortMoviesByAvgRatingDesc(vector<Movie>& movies)
{
  sort(movies.begin(),
    movies.end(),
    [](const Movie& m1, const Movie& m2)
      {
      if (m1.getAvgRating() > m2.getAvgRating())
        return true;
      else if (m1.getAvgRating() < m2.getAvgRating())
        return false;
      else // reviews are equal, secondary sort by movie name:
      {
        if (m1.getMovieName() < m2.getMovieName())
          return true;
        else
          return false;
      }
    }
  );
}


//
// SortMoviesByNumReviewsDesc: sorts the movies by the # of reviews, in
// descending order; secondary sort by Movie name when the avgs are equal.
//
// NOTE: since N is small, simple selection sort is used.
//
void SortMoviesByNumReviewsDesc(vector<Movie>& movies)
{
  sort(movies.begin(),
    movies.end(),
    [](const Movie& m1, const Movie& m2)
    {
      if (m1.getNumReviews() > m2.getNumReviews())
        return true;
      else if (m1.getNumReviews() < m2.getNumReviews())
        return false;
      else // reviews are equal, secondary sort by movie name:
      {
        if (m1.getMovieName() < m2.getMovieName())
          return true;
        else
          return false;
      }
    }
  );
}


//
// getFileName: inputs a filename from the keyboard, make sure the file can be
// opened, and returns the filename if so.  If the file cannot be opened, an
// error message is output and the program is exited.
//
string getFileName()
{
  string filename;

  // input filename from the keyboard:
  getline(cin, filename);

  // make sure filename exists and can be opened:
  ifstream file(filename);
  if (!file.good())
  {
    cout << "**Error: cannot open file: " << filename << endl;
    std::terminate();
  }

  return filename;
}


int main()
{
  // get filenames from the user/stdin:
  string MoviesFileName = "movies.csv";  // getFileName();
  string ReviewsFileName = "reviews.csv"; // getFileName();

  cout << "Inputting movies and reviews..." << endl;
  cout << endl;

  // input movie data:
  vector<Movie> movies = InputMovies(MoviesFileName);

#ifdef NEVER
  for (int i = 0; i < movies.size(); ++i)
  {
    cout << movies[i].ID << ": '"
      << movies[i].Name << "', "
      << movies[i].PubYear << endl;
  }
#endif

  // input & process review data:
  int numReviews = ProcessReviews(ReviewsFileName, movies);

  // output results:
  cout << std::fixed;
  cout << std::setprecision(6);

  cout << "Movies: " << movies.size() << endl;
  cout << "Reviews " << numReviews << endl;

  cout << endl;

  int movieid;

  cout << "Please enter a movie id to search for> ";
  cin >> movieid;

  int index = FindMovie1(movies, movieid);
  if (index == -1)
	  cout << "Movie not found." << endl;
  else
	  cout << movies[index].getMovieName() << " : " << movies[index].getAvgRating() << endl;

  Movie * pm = FindMovie2(movies, movieid);
  if (pm == nullptr)
	  cout << "Movie not found." << endl;
  else
	  cout << pm->getMovieName() << " : " << pm->getAvgRating() << endl;

  auto m = FindMovie(movies, movieid);
  if (m == movies.end())
	  cout << "Movie not found." << endl;
  else
	  cout << m->getMovieName() << " : " << m->getAvgRating() << endl;

  /*








  auto m = std::find_if(movies.begin(), movies.end(), 
    [=](const Movie& m)
    {
      if (m.getMovieID() == movieid)
        return true;
      else
        return false;
    });

  if (m == movies.end())
    cout << "Movie not found..." << endl;
  else
    cout << m->getMovieName()<< ": " << m->getAvgRating() << endl;

  cout << endl;
  cout << endl;

  */
  //
  // done:
  //
  return 0;
}
