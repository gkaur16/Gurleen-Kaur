"""
Where solution code to HW4 should be written.  No other files should
be modified.

Kevin Barrett
"""

import socket
import io
import time
import typing
import struct
import utils
import utils.logging


def send(sock: socket.socket, data: bytes):
    """
    Implementation of the sending logic for sending data over a slow,
    lossy, constrained network.

    Args:
        sock -- A socket object, constructed and initialized to communicate
                over a simulated lossy network.
        data -- A bytes object, containing the data to send over the network.
    """

    # Naive implementation where we chunk the data to be sent into
    # packets as large as the network will allow, and then send them
    # over the network, pausing half a second between sends to let the
    # network "rest" 🙂
    logger = utils.logging.get_logger("hw4-sender")
    chunk_size = utils.MAX_PACKET
    pause = .10
    metadata = 0
    print(type(metadata))
    offsets = range(0, len(data), utils.MAX_PACKET-2)
    for chunk in [data[i:i + chunk_size] for i in offsets]:
        sock.settimeout(1000)
        chunk = bytes([metadata]) + chunk
        try:
              sock.send(chunk)
              metadata = metadata + 1
        except socket.timeout:
            print("Timeout raised and caught.")
        logger.info("Pausing for %f seconds", round(pause, 2))
        time.sleep(pause)
        number = sock.recv(utils.MAX_PACKET)
        print("THis is the packet acknowelgement")
        number = int.from_bytes(number, "big")
        print(number)
        i = number


def recv(sock: socket.socket, dest: io.BufferedIOBase) -> int:
    """
    Implementation of the receiving logic for receiving data over a slow,
    lossy, constrained network.

    Args:
        sock -- A socket object, constructed and initialized to communicate
                over a simulated lossy network.

    Return:
        The number of bytes written to the destination.
    """
    logger = utils.logging.get_logger("hw4-receiver")
    # Naive solution, where we continually read data off the socket
    # until we don't receive any more data, and then return.
    num_bytes = 0
    packetOrder = 0
    while True:
        sock.settimeout(1000)
        data = sock.recv(utils.MAX_PACKET)
        if not data:
            break
        logger.info("Received %d bytes", len(data))
        readbyte = data[0]
        print(readbyte)
        if packetOrder == readbyte:
            data = data[1:]
            print(data)
            dest.write(data)
            num_bytes += len(data)
            dest.flush()
            packetOrder = packetOrder + 1
            print(packetOrder)
            print("This is sent")
        else:
            print(readbyte)
        sock.send(bytes([packetOrder]))

    return num_bytes
