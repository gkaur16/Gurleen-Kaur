"""
Where solution code to HW4 should be written.  No other files should
be modified.
"""

import socket
import io
import time
import typing
import struct
import utils
import utils.logging

def make_header(num: int, delimiter: bytes = b'#@!') -> bytes:
    return (str(num).encode() + delimiter)

def extract_header(data: bytes, delimiter: bytes = b'#@!') -> typing.Tuple[int, bytes]:
    [header, data] = data.split(delimiter, 1)
    return (int(header.decode()), data)

timeout = 0.5     

"""
In Seconds -- We can also do this dynamically, find a way to calculate the time out. 12kb Delay for our Test file. That is 9 chunks. We can compute a moving average
if you choose a timeout less then the delay, you will always miss the packet. 
   
   Store most recent as head - 
   keep list the same size at most 10 elements,
   
   order is up to you 
   
   receive new ack 
   optimtic of the tim you can set it to very low 
   
   can be done by doing several experiments             
"""

def send(sock: socket.socket, data: bytes):
    """
    Implementation of the sending logic for sending data over a slow,
    lossy, constrained network.

    Args:
        sock -- A socket object, constructed and initialized to communicate
                over a simulated lossy network.
        data -- A bytes object, containing the data to send over the network.
    """
    logger = utils.logging.get_logger("hw4-sender")
    id = 0
    i = 0
    while i < len(data):
        header = make_header(id)
        chunk_size = utils.MAX_PACKET - len(header)
        packet = header + data[i:(i + chunk_size)]

        while True:
            logger.info("sending packet of size: %d with id: %d", chunk_size, id)
            sock.send(packet)
            # wait for confirmation
            sock.settimeout(timeout)
            try:
                ack = sock.recv(utils.MAX_PACKET)
                if int(ack.decode()) == id:
                    sock.settimeout(None)
                    break
            except socket.timeout as e:
                logger.info("acknowledgement for packet(id=%d) timed out. Retrying...", id)
        
        id = id + 1
        i = i + chunk_size



def recv(sock: socket.socket, dest: io.BufferedIOBase) -> int:
    """
    Implementation of the receiving logic for receiving data over a slow,
    lossy, constrained network.

    Args:
        sock -- A socket object, constructed and initialized to communicate
                over a simulated lossy network.

    Return:
        The number of bytes written to the destination.
    """
    logger = utils.logging.get_logger("hw4-receiver")
    
    num_bytes = 0
    prev_id = -1
    while True:
        data = sock.recv(utils.MAX_PACKET)
        if not data:
            break
        (id, data) = extract_header(data)
        logger.info("Received packet(id:%d, len:%d).", id, len(data))

        if id == prev_id:
            logger.info("Packet already received before. Ignoring...")
        else:
            logger.info("Sending confirmation...")
            sock.send(str(id).encode())
        
        dest.write(data)
        num_bytes += len(data)
        dest.flush()

    return num_bytes
