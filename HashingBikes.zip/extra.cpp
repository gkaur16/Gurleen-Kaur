/*main.cpp*/

//
// Gurleen Kaur
// U. of Illinois, Chicago
// CS 251: Spring 2020
// Project #06 Part2: hashing bikes and trips
// 
// This program takes the files Stations and Trips and hash it 
// accoring to stationsById, stationsByAbbrev, tripsById and
// bikesById. This program inserts and searched through the hashmap
// using different hash functions and structs and it hashes using 
// probing which helps save the space being used in hashmap
// 
// It allows use to choose from the following options
// 1. If they want to lookup by id
// 2. If they want to lookup by abbreviation
// 3. If they want to lookup tripid
// 4. If they want to lookup how many time a bike is used
// 5. If they want to find nearby stations
// 6. If they want to find similar tripsById 
// 

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <sstream>
#include <algorithm>
#include <queue>
#include <utility>
#include "hash.h"
#include "hashmap.h"
#include "util.h"

using namespace std;

//
// SortingQ
// 
// Class for sorting the pairs
class SortingQ
{
public:
  bool operator()(const pair<string,double>& p1, const pair<string,double>& p2) const
  {
    //
    // return true if p1 < p2 for smaller val  
    // return true if p1 > p2 for larger val
    // 
    if(p1.second > p2.second)
        return true;
     else if(p1.second < p2.second)
         return false;
      else
          return p1.first > p2.first;
  }//bool operator()
};//class SortingQ

//
// DivvyStations
// 
// Stores the data for stations
struct DivvyStations
{
	string ID;
	string Abbrev;
	string Fullname;
	double Latitude;
	double Longitude;
	string Capacity;
	string OnlineDate;
	
	// initiallize
	DivvyStations()
	{
		ID = "";
		Abbrev = "";
		Fullname = "";
		Latitude = 0;
		Longitude = 0;
		Capacity = "";
		OnlineDate = "";
	}//DivvyStations()
};//struct DivvyStations

//
// DivvyTrips
// 
// Stores the data for trips
struct DivvyTrips
{
	string TripID;
	string StartTime;
	string StopTime;
	string BikeId;
	int Duration;
	string From;
	string To;
	string Identifies;
	string BirthYear;
	
	// initiallize
	DivvyTrips()
	{
		TripID = "";
		StartTime = "";
		StopTime = "";
		BikeId = "";
		Duration = 0;
		From = "";
		To = "";
		Identifies = "";
		BirthYear = "";
	}//DivvyTrips()
}; //struct DivvyTrips

//
// DivvyBikeTrips
// 
// Stores the data for bike trips
struct DivvyBikeTrips
{
	string BikeID;
	int UsageBike;
	
	// initiallize
	DivvyBikeTrips()
	{
		BikeID = "";
		UsageBike = 0;	
	}//DivvyBikeTrips()
};//struct DivvyBikeTrips

//
// TripFinder
// 
// Struct for finding stations that followed the same route
struct TripFinder
{
	string ID;
	double Distance;
	
	// initiallize
	TripFinder()
	{
		ID = "";
		Distance = 0;
	}//TripFinder()
};//struct TripFinder

//
// sortTrips
// 
// sort the trips in order
bool sortTrips(const TripFinder& begin, const TripFinder& end)
{
    return (stod(begin.ID) < stod(end.ID));
}//bool sortTrips

//
// string2int
// 
// Converts a string to an integer, unless string is empty, in
// which case 0 is returned.
int string2int(string s)
{
	if (s == "")
		return 0;
	else
		return stoi(s);
}//int string2int

//
// inputDataStations
// 
// Given a filename denoting stations
// inputs that data into the given hash table.
bool inputDataStations(string filename, hashmap<string, DivvyStations>& stationsById, hashmap<string, string>& stationsByAbbrev, int& counterStation)
{
	ifstream  infile(filename);
			
	cout << "Reading " << filename << endl;
	
	if (!infile.good())
	{
		cout << "**Error: unable to open '" << filename << "'..." << endl;
		return false;
	}
	
	// file is open, start processing:
	string line;
	
	getline(infile, line);  // input and discard first row --- header row
		
	while (getline(infile, line))
	{
		stringstream s(line);
		
		string id, abbrev, fullName, latitude, longitude, capacity, onlineData;
		double dubLatitude, dubLongitude;
		
		//
		// format: date,xx xx xx xx xx,yy,z
		// 
		// NOTE: z may be missing (the multiplier)
		// 
		getline(s, id, ',');  // first value => id
		getline(s, abbrev, ',');   // second value => abbrev
		getline(s, fullName, ',');
		getline(s, latitude, ',');
		getline(s, longitude, ',');
		getline(s, capacity, ',');
		getline(s, onlineData, ',');
		
		// convert latitude and longitude to double
		dubLatitude = stod(latitude);
		dubLongitude = stod(longitude);
		
		// we have input the 4 values, and since we are not
		// doing any arithmetic, we can just store them as
		// strings.  If the multiplier is missing then the
		// string is "", which is fine.
		
		//
		// store into hash table
		// 
	    DivvyStations ds;
		
		ds.ID = id;
		ds.Abbrev = abbrev;
		ds.Fullname = fullName;
		ds.Latitude = dubLatitude;
		ds.Longitude = dubLongitude;
		ds.Capacity = capacity;
		ds.OnlineDate = onlineData;

		stationsById.insert(id, ds, HashStationId);  // inserting for station by id
		stationsByAbbrev.insert(abbrev, id, HashStationAbbrev);  // inserting for station by abbrev
		
		counterStation++;
	}
		
	return true;  // we have data to be processed:
}//bool inputDataStations

//
// inputDataTrips
// 
// Given a filename denoting trips
// inputs that data into the given hash table.
bool inputDataTrips(string filename, hashmap<string, DivvyTrips>& tripsById,hashmap<string, DivvyBikeTrips>& bikesById, int counterStation)
{
	ifstream  infile(filename);
		
	cout << "Reading " << filename << endl;
	
	if (!infile.good())
	{
		cout << "**Error: unable to open '" << filename << "'..." << endl;
		return false;
	}
	
	// file is open, start processing:
	string line;
	int count = 0;
	int counterBike = 0;
	
	getline(infile, line);  // input and discard first row --- header row
		
	while (getline(infile, line))
	{
		stringstream s(line);
		
		string tripId, startTime, stopTime, bikeId, duration, from, to, identifies, birthYear;
		
		//
		// format: date,xx xx xx xx xx,yy,z
		// 
		// NOTE: z may be missing (the multiplier)
		// 
		getline(s, tripId, ',');  // first value => tripId
		getline(s, startTime, ',');   // second value => startTime
		getline(s, stopTime, ',');
		getline(s, bikeId, ',');
		getline(s, duration, ',');
		getline(s, from, ',');
		getline(s, to, ',');
		getline(s, identifies, ',');
		getline(s, birthYear, ',');
		
		// we have input the 4 values, and since we are not
		// doing any arithmetic, we can just store them as
		// strings.  If the multiplier is missing then the
		// string is "", which is fine.
		int intDuration = stoi(duration);
		
		//
		// store into hash table
		// 
	    DivvyTrips dt;
		
		dt.TripID = tripId;
		dt.StartTime = startTime;
		dt.StopTime = stopTime;
		dt.BikeId = bikeId;
		dt.Duration = intDuration;
		dt.From = from;
		dt.To = to;
		dt.Identifies = identifies; 
		dt.BirthYear = birthYear;

		// inserting for trips by id
		tripsById.insert(tripId, dt, HashTripsId);
		
		//
		// store into hash table
		// 
		DivvyBikeTrips db;
		
		db.BikeID = bikeId;
		db.UsageBike = 0;
		
		// if usage is already in the hashmap then add 1 to it else set usage to 1
		if(bikesById.search(bikeId, db, HashBikeId))
			db.UsageBike++;
		else
		{
			db.UsageBike = 1;
			counterBike++;
		}
		
		// inserting for getting usage 
		bikesById.insert(bikeId, db, HashBikeId);
		count++;
	}//while (
	
	cout << endl << "# of stations: " << counterStation << endl;
	cout << "# of trips: " << count << endl;
	cout << "# of bikes: " << counterBike << endl;
	
	return true;  // we have data to be processed:
}//bool inputDataTrips

//
// checkNumeric
//
// check if a string sent to the function is numeric
bool checkNumeric(string s)
{
   if (s.length() == 0)
     return false;
     
   // iterate through the string
   for(char c : s)
   {
      if (!isdigit(c))  // if c is not a digit, it cannot be numeric:
        return false;
   }
   
   // if get here, all chars are digits, so it's numeric:
   return true;
}//bool checkNumeric

//
// findDuration
//  
// find hour minutes and seconds from seconds sent to the function
void findDuration(int convertSeconds)
{
	int hours = 0, mins = 0, seconds = 0;
	
	// find hours
	hours = convertSeconds / 3600;
	convertSeconds %= 3600;
	
	// find mins
	mins = convertSeconds / 60;
	convertSeconds %= 60;
	
	// find seconds
	seconds = convertSeconds;
	
	// output
	cout << " Duration: ";
	
	if(hours > 0)
		cout << hours << " hours, ";
	
	if(mins > 0)
		cout << mins << " minutes, ";
	
	 cout << seconds << " seconds" << endl;
}//void findDuration

//
// nearbyHelper
//
// Helper function to find the nearby stations given latitude / longitude
void nearbyHelper(string userInput, hashmap<string, DivvyStations>& stationsById)
{
	DivvyStations divvy;
	stringstream k(userInput);
	
	string firstWord, latitude, longitude, distance;
	getline(k, firstWord, ' ');       // getting nearby
	getline(k, latitude, ' ');        // latitude
	getline(k, longitude, ' ');       // longitude
	getline(k, distance, ' ');        // range of distance they are looking in
	
	priority_queue<pair<string, double>,
    vector<pair<string, double>>,
    SortingQ>  myQueue;
	
	bool searchID;
	double getDistance;
	
	// vector for collecting the stations nearby
	vector<string> getIDS = stationsById.collectStations();
	
	// iterating through the vector
	for(size_t div = 0; div < getIDS.size(); div++)
	{
		searchID = stationsById.search(getIDS[div], divvy, HashStationId);
		
		// if id is found in HashStationId then get the distance and push it to the queue
		if(searchID)
		{
			// get distance between latitude and longitude
			getDistance = distBetween2Points(stod(latitude), stod(longitude), divvy.Latitude, divvy.Longitude);
			
			if(getDistance <= stod(distance))
				 myQueue.push(make_pair(divvy.ID, getDistance));
		}
	}
	
	// if nothing is pushed to the queue then return nothing found
	if(myQueue.size() == 0)
	{
         cout << "Stations within " << distance << " miles of (" << latitude << ", " << longitude << ")" << endl;
         cout << " none found " << endl;
         cout << endl;
         return;
     }
	
	cout << "Stations within " << distance << " miles of (" << latitude << ", " << longitude << ")" << endl;
	
	// keep displaying the stations and popping until the queue is empty
    while (!myQueue.empty())
	{
		auto s = myQueue.top();
		myQueue.pop();

		cout << " station " << s.first << ": " << s.second << " miles" << endl;
	}//while (!myQueue
    cout << endl;
}//void nearbyHelper

//
// getSimilar
//
// function to get the stations that are closer to the station given
vector<TripFinder> getSimilar(vector<string> myList, hashmap<string, DivvyStations>& stationsById, double latitude, double longitude, string distance)
{
	vector<TripFinder> foundIDS;
	DivvyStations div;
	double getDistance;
	TripFinder tf;
	
	// iterate through the whole vector myList
	for(size_t i = 0; i < myList.size(); i++)
	{
		// search the HashStationId hashmap and get the values stored
		stationsById.search(myList[i], div, HashStationId);
		getDistance = distBetween2Points(latitude,longitude, div.Latitude, div.Longitude);
		
		// if getDistance is smaller or equal to distance given then add to the values to TripFinder struct
		if(getDistance <= stod(distance))
		{
			tf.ID = myList[i];
            tf.Distance = getDistance;
            foundIDS.push_back(tf); 
		}
	}//for(size_t
	return foundIDS;	
}//vector<TripFinder> getSimilar

//
// SearchTrips
//
// function to find the stations nearby to the coordinates given
void SearchTrips(string userInput, hashmap<string, DivvyStations>& stationsById, hashmap<string, DivvyTrips>& tripsById)
{
	stringstream k(userInput);
	
	string firstWord, tripID, distance;
	getline(k, firstWord, ' ');      // similar
	getline(k, tripID, ' ');         // trip id starting from Tr
	getline(k, distance, ' ');	     // distance they are looking in between
	
	vector<TripFinder> fStation;
    vector<TripFinder> tStation;
	
	vector<string> getStationIDS = stationsById.collectStations();
    vector<string> getTripIDS    = tripsById.collectStations();
	
	DivvyStations from;
	DivvyStations to;
	DivvyTrips div;
	
	// search for the trip id given and get the data
	bool tripChecker = tripsById.search(tripID, div, HashTripsId);
	cout << "Trips that follow a similar path (+/-" << distance << " miles) as " << tripID << endl;
	
	// if not found that return trip not found
	if(!tripChecker)
		cout << " no such trip" << endl << endl;
	else
	{		
		// use the from data from trip id to search stations by id and get data
		stationsById.search(div.From, from, HashStationId);
		fStation = getSimilar(getStationIDS, stationsById, from.Latitude, from.Longitude, distance);
		
		// use the to data from trip id to search stations by id and get data
		stationsById.search(div.To, to, HashStationId);
		tStation = getSimilar(getStationIDS, stationsById, to.Latitude, to.Longitude, distance);
		
		DivvyStations fromStation;
		DivvyStations toStation;
		int counter = 0;
		
		// iterate through the getTripIDS
		for(size_t i = 0; i < getTripIDS.size(); i++)
		{
			bool checkTrip = tripsById.search(getTripIDS[i], div, HashTripsId);
			
			// if id is found then call the helper function to get the closer stations
			if(checkTrip)
			{
				stationsById.search(div.From, fromStation, HashStationId);
				stationsById.search(div.To, toStation, HashStationId);
				
				double getFromDistance = distBetween2Points(fromStation.Latitude, fromStation.Longitude, from.Latitude, from.Longitude);
				double getToDistance = distBetween2Points(toStation.Latitude, toStation.Longitude, to.Latitude, to.Longitude);
				
				// check for from distance and to distance and and 1 to the counter
				if(getFromDistance <= stod(distance) && getToDistance <= stod(distance))
					counter++;
			}
		}
		
		// sort the stations in order
		sort(fStation.begin(), fStation.end(), sortTrips);
		sort(tStation.begin(), tStation.end(), sortTrips);
		
		// print the starting stations
		cout << " nearby starting points: ";
		for(size_t i = 0; i < fStation.size(); i++)
			cout << fStation[i].ID << " " ;
		
		// print the end stations
		cout << endl;
		cout << " nearby ending points: ";
		for(size_t j = 0; j < tStation.size(); j++)
			cout << tStation[j].ID << " " ;

		cout << endl;
		cout << " trip count: " << counter << endl;
		cout << endl;	
	}//else{
}//void SearchTrips

//
// display
//
// display data for each command
void displayData(DivvyStations ds, string divvy)
{
	// if i is 1 then display every command
	if(divvy == "help")
	{
		cout << "1. Lookup station by id" << endl;
		cout << "2. Lookup station by abbreviation (e.g. “Adler”)" << endl;
		cout << "3. Lookup a bike trip by trip id (e.g. “Tr10426561”)" << endl;
		cout << "4. Lookup bike usage by bike id (e.g. “B5218”)" << endl;
		cout << "5. Find nearby stations based on latitude / longitude" << endl;
		cout << "6. Find similar trips based on latitude / longitude" << endl;
	}
	// if i is 2 then display data for stations by id or stations by abbrev
	else
	{
		cout << "Station:" << endl;
		cout << " ID: " << ds.ID << endl;
		cout << " Abbrev: " << ds.Abbrev << endl;
		cout << " Fullname: " << ds.Fullname << endl;
		cout << " Location: (" << setprecision(6) << ds.Latitude << ", " 
			 << setprecision(6) << ds.Longitude << ")" << endl;
		cout << " Capacity: " << ds.Capacity << endl;
		cout << " Online date: " << ds.OnlineDate << endl;
	}
}//void displayData

// 
// main
// 
// main to process the user input and display the data accordingly
int main()
{
	//
	// Allocate our hash table
	// 
	hashmap<string, DivvyStations> stationsById(10000); // Key = station id and is numeric, Value = DivvyStations struct
	hashmap<string, string> stationsByAbbrev(10000);    // Key = station abbrev and is string, Value = station id
	hashmap<string, DivvyTrips> tripsById(2500000);     // Key = trip id starts from Tr, Value = DivvyTrips struct
	hashmap<string, DivvyBikeTrips> bikesById(50000);   // Key = bike by id, Value = DivvyBikeTrips struct
	
	cout << "** DIVVY analysis program **" << endl << endl;
	//
	// getting the fileNames
	// 
	string filenameStation, filenameTrip;
	
	cout << "Enter stations file> ";
	cin >> filenameStation;
	
	cout << "Enter trips file> ";
	cin >> filenameTrip;
	
	cout << endl;
	
	int counterStation = 0;
	
	// store the data in filenames into appropriate hashmap
	bool successStation = inputDataStations(filenameStation, stationsById, stationsByAbbrev, counterStation);
	bool successTrip = inputDataTrips(filenameTrip, tripsById, bikesById, counterStation);
									
	//
	// did we input anything?
	// 
	if (!successStation || !successTrip)
	{
		cout << "No data, file not found?" << endl;
		return 0;
	}
	
	//
	// allow the user to enter what they want to do
	// 
	cin.ignore(256,'\n');
	
	string divvy;
	
	cout << endl;
	cout << "Please enter a command, help, or #> ";
	getline(cin, divvy);

	//
	// user testing:
	//
	while (divvy != "#")
	{
		//
		// we have a command, let's look in hash table and
		// see if we have any data:
		// 
		
		DivvyStations ds;
		DivvyTrips dt;
		DivvyBikeTrips db;

		string abbrevId;
		
		bool found = false;
		
		// if user inputs help then display the commands
		if(divvy == "help")
			displayData(ds, divvy);
		
		// checking for stations by Id if user inputs id
		else if(checkNumeric(divvy))
		{			
			found = stationsById.search(divvy, ds, HashStationId);
			
			// search the id if found then print the data
			if (!found)
				cout << "Station not found" << endl;
			else
			{
				displayData(ds, divvy);
			}
		}//else if(checkNumeric
		
		// check for trip by id if user inputs trip id
		else if(divvy[0] == 'T' && divvy[1] == 'r')
		{		
			found = tripsById.search(divvy, dt, HashTripsId); 
			
			// search for trip id if found return the data
			if(!found)
				cout << "Trip not found" << endl;
			else
			{
				cout << "Trip:" << endl;
				cout << " ID: " << dt.TripID << endl;
				cout << " Starttime: " << dt.StartTime << endl;
				cout << " BikeId: " << dt.BikeId << endl;
				
				// use the function to get the duration in hours, minutes and seconds
				findDuration(dt.Duration);

				// use station by id to get the abbreviation for from
				found = stationsById.search(dt.From, ds, HashStationId);
				cout << " From station: " << ds.Abbrev << " (" << dt.From << ")" << endl;

				// use station by id to get the abbreviation for to
				found = stationsById.search(dt.To, ds, HashStationId);
				cout << " To station: " << ds.Abbrev << " (" << dt.To << ")" << endl;
				cout << " Rider identifies as: " << dt.Identifies << endl;
				cout << " Birthyear: " << dt.BirthYear << endl;
			}
		}//else if(divvy[0] == 'T'
		
		// check for times the bike is used if user inputs bike id
		else if(divvy[0] == 'B')
		{
			found = bikesById.search(divvy, db, HashBikeId);
			if(!found)
				cout << "Bike not found" << endl;
			else
			{
				cout << "Bike:" << endl;
				cout << " ID: " << db.BikeID << endl;
				cout << " Usage: " << db.UsageBike << endl;
			}
		}//else if(divvy[0] == 'B'
		
		// checking for nearby stations if user inputs nearby
		else if((divvy.substr(0,6) == "nearby"))
			nearbyHelper(divvy, stationsById);
		
		// checking for similar stations if user inputs similar
		else if((divvy.substr(0,7) == "similar"))
			SearchTrips(divvy, stationsById, tripsById);

		// checking for station by abbrev if user inputs some string
		else
		{
			found = stationsByAbbrev.search(divvy, abbrevId, HashStationAbbrev);
			
		    // search for station abbreviation if found return the data
			if (!found)
				cout << "Station not found" << endl;
			else
			{
				found = stationsById.search(abbrevId, ds, HashStationId);
				displayData(ds, divvy);
			}
		}//else if(divvy != "")
		
		cout << endl;
		cout << "Please enter a command, help, or #> ";
		getline(cin, divvy);
	}//while (divvy != "#")
	
	return 0;
}//int main()