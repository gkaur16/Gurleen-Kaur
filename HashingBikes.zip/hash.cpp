/*hash.cpp*/

//
// Gurleen Kaur
// U. of Illinois, Chicago
// CS 251: Spring 2020
// Project #06 Part2: hashing bikes and trips
// 
// This file hashes 
// station by id, 
// station by abbrev,
// trip by id,
// bike by id,
// 

#include <iostream>
#include <string>
#include <cctype>  /*isdigit*/
#include <regex>   /*regular expressions*/

#include "hash.h"

using namespace std;

//
// isNumeric
//
// Returns true if the given string is numeric (all digits), false
// if not.  If the string is empty, false is returned since there 
// are no digits present.
//
bool isNumeric(string s)
{
	//
	// A string is numeric if it contains 1 or more digits, so let's
	// use a regular expression to check that.
	//
	// we are using POSIX basic notation for regular expressions, see
	//   https://en.cppreference.com/w/cpp/regex/ecmascript
	// where [:d:] means digit, [[:d:]] means match a single digit.
	// The + means match the preceding sub-expression 1 or more times.
	//
	regex pattern("[[:d:]]+", regex::ECMAScript);

	smatch matchResults;  // provides more details on the match

	if (regex_match(s, matchResults, pattern))
		return true;
	else
		return false;
}//bool isNumeric

//
// HashStationId
//
// This function hashes station by id
// Where Id is all numeric like "123"
int HashStationId(string ID, int N)
{
	int index = 0;
	
	// check if ID is numeric then convert it to int and store it in index
	if(isNumeric(ID))
		index = stoi(ID);
	
	return index % N;
}//int HashStationId

//
// HashStationId
//
// This function hashes station by abbreviation 
// abbreviation is all string like "Abcd efgh"
int HashStationAbbrev(string Abbrev, int N)
{
	int index = 0;
	
	// go through the whole string and store the value of characters inside index
	for(int i = 0; Abbrev[i] != '\0'; i++)
		index += Abbrev[i];
	
	return index%N;
}//int HashStationAbbrev

//
// HashTripsId
//
// This function hashes trips by ID
// And Id starts from Tr and the rest of 
// the values are numeric like "Tr123"
int HashTripsId(string tripId, int N)
{
	int index = 0;
	
	// if first two values are Tr
	if(tripId[0] == 'T' && tripId[1] == 'r')
	{
		// erase first two values
		tripId.erase(0,2);
		
		// Hash the rest after checking its numeric
		if(isNumeric(tripId))
			index = stoi(tripId);
	}
	return index % N;
}//int HashTripsId

//
// HashBikeId
//
// This function hashes bikes by ID
// And Id starts from B and the rest of 
// the values are numeric like "B123"
int HashBikeId(string BikeId, int N)
{
	int index = 0;
	
	// if the first value is B
	if(BikeId[0] == 'B')
	{
		BikeId.erase(0,1);
		
		// Hash the rest after checking its numeric
		if(isNumeric(BikeId))
			index = stoi(BikeId);
	}
	
	return index % N;
}//int HashBikeId