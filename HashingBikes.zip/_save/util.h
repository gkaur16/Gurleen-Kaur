/*util.h*/

//
// Prof. Joe Hummel
// U. of Illinois, Chicago
// CS 251: Spring 2020
// Project #06: hashing DIVVY data
// 

#include <iostream>
#include <cmath>

using namespace std;

double distBetween2Points(double lat1, double long1, double lat2, double long2);
